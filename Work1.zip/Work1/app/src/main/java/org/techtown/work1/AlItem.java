package org.techtown.work1;


import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class AlItem extends AppCompatActivity {

    ListAdapter adapter;

    ArrayList<ListItem> finalAllist = new ArrayList<ListItem>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_al_item);

        ListView listView = (ListView) findViewById(R.id.listView);
        adapter = new ListAdapter();
        listView.setAdapter(adapter);

        Intent intent = getIntent();
        finalAllist = (ArrayList<ListItem>) intent.getSerializableExtra("allist");
        for (int i = 0; i < finalAllist.size(); i++) {
            adapter.addItem(finalAllist.get(i));
            adapter.notifyDataSetChanged();
        }
    }
}
