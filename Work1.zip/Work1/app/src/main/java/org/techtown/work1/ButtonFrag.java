package org.techtown.work1;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class ButtonFrag extends Fragment {
    Documentation activity;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        activity = (Documentation) getActivity();
    }


    @Override
    public void onDetach() {
        super.onDetach();

        activity = null;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_button, container, false);

        Button button_m = (Button) rootView.findViewById(R.id.button_j);
        button_m.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.ChangeFragment(1);
            }
        });

        Button button_k = (Button) rootView.findViewById(R.id.button_k);
        button_k.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.ChangeFragment(2);
            }
        });

        Button button_d = (Button) rootView.findViewById(R.id.button_d);
        button_d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.ChangeFragment(3);
            }
        });

        Button button_x = (Button) rootView.findViewById(R.id.button_x);
        button_x.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.ChangeFragment(4);
            }
        });

        Button button_t = (Button) rootView.findViewById(R.id.button_t);
        button_t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.ChangeFragment(5);
            }
        });

        Button button_ga = (Button) rootView.findViewById(R.id.button_ga);
        button_ga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.ChangeFragment(6);
            }
        });

        Button button_gon = (Button) rootView.findViewById(R.id.button_gon);
        button_gon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.ChangeFragment(7);
            }
        });

        Button button_al = (Button) rootView.findViewById(R.id.button_al);
        button_al.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.ChangeFragment(8);
            }
        });

        return rootView;
    }

}