package org.techtown.work1;

import android.graphics.Bitmap;

public class CatInformation {

    private String[] CatData;

    public CatInformation(String name, String sex, String age, String handling, String desexualize, String state, String chart, String etc) {
        CatData = new String[10];
        CatData[0] = name;
        CatData[1] = sex;
        CatData[2] = age;
        CatData[3] = handling;
        CatData[4] = desexualize;
        CatData[5] = state;
        CatData[6] = chart;
        CatData[7] = etc;
        //CatData[8] = bitmapfile.toString();
    }

    public String[] getCatData() {
        return CatData;
    }

    public void setCatData(String[] catData) {
        CatData = catData;
    }

    public String getData(int index) {
        return CatData[index];
    }

}