package org.techtown.work1;

import android.graphics.Bitmap;

public class CatInformation {
    String name;
    String sex;
    int age;
    String properties;
    Bitmap bitmapfile;

    public CatInformation(String name, String sex, int age, String properties, Bitmap bitmapfile) {
        this.name = name;
        this.sex = sex;
        this.age = age;
        this.properties = properties;
        this.bitmapfile = bitmapfile;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getProperties() {
        return properties;
    }

    public void setProperties(String properties) {
        this.properties = properties;
    }

    public Bitmap getBitmapfile() {
        return bitmapfile;
    }

    public void setBitmapfile(Bitmap bitmapfile) {
        this.bitmapfile = bitmapfile;
    }
}