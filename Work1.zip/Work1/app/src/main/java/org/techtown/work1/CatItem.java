package org.techtown.work1;

import android.widget.ImageView;

public class CatItem {
    int resId;
    String name;

    public CatItem(int resId, String name) {
        this.resId = resId;
        this.name = name;
    }

    public CatItem(int resId) {
        this.resId = resId;
    }

    public int getResId() {
        return resId;
    }

    public void setResId(int resId) {
        this.resId = resId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
