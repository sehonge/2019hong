package org.techtown.work1;

import android.graphics.Bitmap;
import android.widget.ImageView;

public class CatItem {
    Bitmap bitmap;
    String name;
    public CatItem(Bitmap bitmap, String name) {
        this.bitmap = bitmap;
        this.name = name;
    }

    public CatItem(Bitmap bitmap) {
        this.bitmap = bitmap;
    }

    public Bitmap getBitmap() {
        return bitmap;
    }

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
