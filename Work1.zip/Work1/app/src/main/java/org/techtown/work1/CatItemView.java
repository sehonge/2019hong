package org.techtown.work1;

import android.content.Context;
import android.support.constraint.ConstraintLayout;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.TextView;

public class CatItemView extends ConstraintLayout {
    ImageView imageView;
    TextView textView;

    public CatItemView(Context context) {
        super(context);
        init(context);
    }

    public CatItemView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }
    public void init(Context context){
        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.cat_item,this,true);

        imageView=(ImageView)findViewById(R.id.imageView4);
        textView = (TextView) findViewById(R.id.textView6);

    }
    public void setImageView(int resId){
        imageView.setImageResource(resId);
    }

    public void setName(String name) {
        textView.setText(name);
    }
}