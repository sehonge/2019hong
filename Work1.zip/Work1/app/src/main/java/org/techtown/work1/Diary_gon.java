package org.techtown.work1;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class Diary_gon extends Fragment {

    List activity;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        activity=(List)getActivity();
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    ListAdapter adapter;

    ArrayList<ListItem> finalGonlist=new ArrayList<ListItem>();
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup)inflater.inflate(R.layout.fragment_diary,container,false);
        Button button = (Button)rootView.findViewById(R.id.backbutton);
        ListView listView = (ListView) rootView.findViewById(R.id.listView);

        TextView textView = (TextView) rootView.findViewById(R.id.textView_foodcenter);

        textView.setText("곤자가 쓰레기장");

        adapter = new ListAdapter();
        listView.setAdapter(adapter);

        Bundle bundle = getArguments();
        finalGonlist=(ArrayList<ListItem>) bundle.getSerializable("gonlist");

        for (int i = 0; i < finalGonlist.size(); i++) {
            adapter.addItem(finalGonlist.get(i));
            adapter.notifyDataSetChanged();
        }
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    activity.FragmentChange(0);
                }
                catch(NullPointerException e){
                    Intent intent = new Intent(getContext(),List.class);
                    startActivity(intent);
                }
            }
        });

        return rootView;
    }
}