package org.techtown.work1;

import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Documentation extends AppCompatActivity {

    ButtonFrag fragment_btn;
    MainGateFrag fragment_m;
    KFrag fragment_k;
    FragmentManager manager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doc);

        manager =getSupportFragmentManager();
       // fragment_btn = (ButtonFrag)manager.findFragmentById(R.id.fragmentbutton);
        fragment_btn=new ButtonFrag();
        getSupportFragmentManager().beginTransaction().add(R.id.fragment,fragment_btn).commit();


    }

    public void ChangeFragment(int index) {

        fragment_m = new MainGateFrag();
        fragment_k = new KFrag();

        if(index == 1) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment, fragment_m).commit();
        } else if (index == 2) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment, fragment_k).commit();
        } else if (index == 3) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment, fragment_btn).commit();
        }
    }
}
