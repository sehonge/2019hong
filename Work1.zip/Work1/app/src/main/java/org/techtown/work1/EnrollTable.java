package org.techtown.work1;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;

public class EnrollTable extends AppCompatActivity {

    Animation flow1;
    Animation flow2;
    Animation flow3;
    Animation flow4;
    Animation flow5;

    //현재 시간
    long curTime = System.currentTimeMillis();
    Date timeData = new Date(curTime);
    SimpleDateFormat timeDataFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
    String timeString = timeDataFormat.format(timeData);

    TextView textView;
    //날씨
    ImageView image1;
    ImageView image2;
    ImageView image3;
    ImageView image4;
    ImageView image5;

    int weather;

    //시크바

    SeekBar k_food;
    SeekBar k_water;
    TextView k_food_p;
    TextView k_water_p;
    //버튼
    Button enroll;
    //작성
    EditText writer, k_info;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enroll_table);
        flow1= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.flow1);
        flow2= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.flow2);
        flow3= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.flow3);
        flow4= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.flow4);
        flow5= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.flow5);

        textView = (TextView) findViewById(R.id.textView);
        textView.setText(timeString);

        image1 = (ImageView) findViewById(R.id.imageView2);
        image2 = (ImageView) findViewById(R.id.imageView3);
        image3 = (ImageView) findViewById(R.id.imageView4);
        image4 = (ImageView) findViewById(R.id.imageView5);
        image5 = (ImageView) findViewById(R.id.imageView6);

        enroll = (Button) findViewById(R.id.enroll);
        writer=(EditText)findViewById(R.id.writer);
        k_info=(EditText)findViewById(R.id.k_info);




        image1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                weather = R.drawable.a;
                todayWeather(weather);
            }
        });
        image2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                weather = R.drawable.b;
                todayWeather(weather);
            }
        });
        image3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                weather = R.drawable.c;
                todayWeather(weather);
            }
        });
        image4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                weather = R.drawable.d;
                todayWeather(weather);
            }
        });
        image5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                weather = R.drawable.e;
                todayWeather(weather);
            }

        });

        k_food_p = (TextView) findViewById(R.id.textView11);
        k_water_p =(TextView) findViewById(R.id.textView12);

        k_food = (SeekBar) findViewById(R.id.k_seek_food);
        k_food.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                k_food_p.setText(String.valueOf(progress)+"%");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        k_water = (SeekBar) findViewById(R.id.k_seek_water);
        k_water.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                k_water_p.setText(String.valueOf(progress)+"%");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        enroll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = getIntent();

                String food = k_food_p.getText().toString();
                String water = k_water_p.getText().toString();
                String intentwriter = writer.getText().toString();
                String time = timeString;
                String extrainformation = k_info.getText().toString();
                int weatherid = weather;

                ListItem newitem = new ListItem(intentwriter,food,water,time,weatherid,extrainformation);
                intent.putExtra("newlistinfo",newitem);
                setResult(RESULT_OK,intent);

                if(writer.getText().toString().length()<1){
                    mustWrite("작성자");
                }
                else showMessage();

            }
        });
    }

    @Override
    public void onBackPressed(){
        AlertDialog.Builder builder = new AlertDialog.Builder (this);
        builder.setMessage("작성을 취소하시겠습니까?");
        builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        builder.setPositiveButton("아니오", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        AlertDialog dialog=builder.create();
        dialog.show();
        //super.onBackPressed();
    }

    public void mustWrite(String word){
        String alertword=word+"를 반드시 입력해주세요.";
        AlertDialog.Builder builder = new AlertDialog.Builder (this);
        builder.setMessage(alertword);
        builder.setNeutralButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        AlertDialog dialog=builder.create();
        dialog.show();
    }
    public void showMessage(){
        AlertDialog.Builder builder = new AlertDialog.Builder (this);
        builder.setMessage("등록되었습니다.");
        builder.setNeutralButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        AlertDialog dialog=builder.create();
        dialog.show();
        //startActivity(intent);
    }

    private void todayWeather(int num){
        switch (num){
            case R.drawable.a :
                image1.setVisibility(View.VISIBLE);
                image2.setVisibility(View.INVISIBLE);
                image3.setVisibility(View.INVISIBLE);
                image4.setVisibility(View.INVISIBLE);
                image5.setVisibility(View.INVISIBLE);
                image1.startAnimation(flow1);
                break;
            case R.drawable.b :
                image1.setVisibility(View.INVISIBLE);
                image2.setVisibility(View.VISIBLE);
                image3.setVisibility(View.INVISIBLE);
                image4.setVisibility(View.INVISIBLE);
                image5.setVisibility(View.INVISIBLE);
                image2.startAnimation(flow2);
                break;
            case R.drawable.c :
                image1.setVisibility(View.INVISIBLE);
                image2.setVisibility(View.INVISIBLE);
                image3.setVisibility(View.VISIBLE);
                image4.setVisibility(View.INVISIBLE);
                image5.setVisibility(View.INVISIBLE);
                image3.startAnimation(flow3);
                break;
            case R.drawable.d :
                image1.setVisibility(View.INVISIBLE);
                image2.setVisibility(View.INVISIBLE);
                image3.setVisibility(View.INVISIBLE);
                image4.setVisibility(View.VISIBLE);
                image5.setVisibility(View.INVISIBLE);
                image4.startAnimation(flow4);
                break;
            case R.drawable.e :
                image1.setVisibility(View.INVISIBLE);
                image2.setVisibility(View.INVISIBLE);
                image3.setVisibility(View.INVISIBLE);
                image4.setVisibility(View.INVISIBLE);
                image5.setVisibility(View.VISIBLE);
                image5.startAnimation(flow5);
                break;
        }
    }


}
