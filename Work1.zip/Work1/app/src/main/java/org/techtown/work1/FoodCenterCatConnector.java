package org.techtown.work1;

import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class FoodCenterCatConnector extends Thread {

    String temp;
    final String ipAddress = "10.1.176.251";

    public void run() {
        final String output = request("http://" + ipAddress + "/foodcenter_cat.php");

        temp = output;
    }

    public String getTemp() {
        return temp;
    }

    public String request(String urlStr) {
        StringBuilder output = new StringBuilder();
        try {
            URL url = new URL(urlStr);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            if (con != null) {
                con.setConnectTimeout(10000);
                con.setRequestMethod("GET");
                con.setDoInput(true);
                con.setDoOutput(true);

                int resCode = con.getResponseCode();
                if (resCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String line;
                    while (true) {
                        line = reader.readLine();
                        if (line == null) {
                            break;
                        }
                        output.append(line + "\n");
                    }
                    reader.close();
                }
                con.disconnect();
            }
        } catch (Exception e) {
            Log.e("SampleHTTP", "Exception in processing response.", e);
            e.printStackTrace();
        }
        return output.toString();
    }
}
