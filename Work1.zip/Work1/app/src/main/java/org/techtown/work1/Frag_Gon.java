package org.techtown.work1;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class Frag_Gon extends Fragment {
    Documentation activity;
    public static CatAdapter adapter;
    ViewGroup rootView;
    ArrayList<CatInformation> catinform_gon = new ArrayList<CatInformation>();
    GridView gridView2;
    ArrayList<FoodCenterCat> fc_cat = new ArrayList<FoodCenterCat>();
    String img1;
    String img2;
    String img3;
    String imgUrl="http://34.85.38.141/";
    Bitmap file1;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        activity = (Documentation) getActivity();
    }

    @Override
    public void onDetach() {
        super.onDetach();

        activity = null;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        adapter = new CatAdapter();
        rootView = (ViewGroup) inflater.inflate(R.layout.fragment_cat_info, container, false);
        gridView2 = (GridView) rootView.findViewById(R.id.gridView);

        FoodCenterCatConnector foodCenterCatConnector = new FoodCenterCatConnector();
        foodCenterCatConnector.start();

        try {
            foodCenterCatConnector.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        String result_fc = foodCenterCatConnector.getTemp();
        ParseJSON_fc(result_fc);

        CatInfoConnector catInfoConnector = new CatInfoConnector();
        catInfoConnector.start();

        try {
            catInfoConnector.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        String result = catInfoConnector.getTemp();
        ParseJSON(result);

        Button button_back = (Button) rootView.findViewById(R.id.button_back);

        button_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.ChangeFragment(0);
            }
        });

        return rootView;
    }

    public void ParseJSON_fc(String target) {

        String fc;
        String cat;

        try {
            JSONObject root = new JSONObject(target);
            JSONArray ja = root.getJSONArray("results");

            for (int i = 0; i < ja.length(); i++) {
                JSONObject jo = ja.getJSONObject(i);
                fc = jo.getString("fc");
                cat = jo.getString("cat");

                if (fc.equals("7")) {
                    fc_cat.add(new FoodCenterCat(fc, cat));
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void ParseJSON(String target) {

        String name;
        String sex;
        String age;
        String handling;
        String desexualize;
        String state;
        String chart;
        String etc;

        try {
            JSONObject root = new JSONObject(target);
            JSONArray ja = root.getJSONArray("results");

            for (int i = 0; i < ja.length(); i++) {
                JSONObject jo = ja.getJSONObject(i);
                name = jo.getString("name");
                sex = jo.getString("sex");
                age = jo.getString("age");
                handling = jo.getString("handling");
                desexualize = jo.getString("desexualize");
                state = jo.getString("state");
                chart = jo.getString("chart");
                etc = jo.getString("etc");
                /*img1 = jo.getString("img1");
                img2 = jo.getString("img2");
                img3 = jo.getString("img3");*/
                img1="img1.PNG";
                img2="img2.PNG";
                img3="img3.PNG";

                for (int j = 0; j < fc_cat.size(); j++) {
                    if (name.equals(fc_cat.get(j).getCat())) {
                        catinform_gon.add(new CatInformation(name, sex, age, handling, desexualize, state, chart, etc));

                        imgLoad th = new imgLoad();
                        th.start();
                        try{
                            th.join();
                        }
                        catch(Exception e){
                            e.printStackTrace();
                        }
                        adapter.addItem(new CatItem(file1, name));
                    }
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        gridView2.setAdapter(adapter);

        gridView2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                CatItem item = (CatItem) adapter.getItem(position);
                for (int i = 0; i < catinform_gon.size(); i++) {
                    CatInformation candidate = catinform_gon.get(i);

                    if (candidate.getData(0) == item.name) {
                        Intent intent = new Intent(getContext(), InputAct.class);

                        intent.putExtra("name", candidate.getData(0));
                        intent.putExtra("sex", candidate.getData(1));
                        intent.putExtra("age", candidate.getData(2));
                        intent.putExtra("handling", candidate.getData(3));
                        intent.putExtra("desexualize", candidate.getData(4));
                        intent.putExtra("state", candidate.getData(5));
                        intent.putExtra("chart", candidate.getData(6));
                        intent.putExtra("etc", candidate.getData(7));
                        intent.putExtra("img1",img1);
                        intent.putExtra("img2",img2);
                        intent.putExtra("img3",img3);
                        startActivity(intent);
                    }
                }
            }
        });
    }
    class imgLoad extends Thread{
        String str = imgUrl+img1;
        public void run(){
            try{
                URL url = new URL(str);
                HttpURLConnection conn = (HttpURLConnection)url.openConnection();
                conn.setDoInput(true);
                conn.connect();

                InputStream is = conn.getInputStream();
                file1 = BitmapFactory.decodeStream(is);
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
    }
}


