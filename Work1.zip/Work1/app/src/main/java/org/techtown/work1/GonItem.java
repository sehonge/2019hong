package org.techtown.work1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class GonItem extends AppCompatActivity {

    ListAdapter adapter;

    ArrayList<ListItem> finalGonlist = new ArrayList<ListItem>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gon_item);

        ListView listView = (ListView) findViewById(R.id.listView);
        adapter = new ListAdapter();
        listView.setAdapter(adapter);


        Intent intent = getIntent();
        finalGonlist = (ArrayList<ListItem>) intent.getSerializableExtra("gonlist");
        for (int i = 0; i < finalGonlist.size(); i++) {
            adapter.addItem(finalGonlist.get(i));
            adapter.notifyDataSetChanged();
        }
    }
}
