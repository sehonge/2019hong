package org.techtown.work1;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.TextView;


public class InputAct extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input);

        TextView nameText = (TextView) findViewById(R.id.textView_name);
        TextView sexText = (TextView) findViewById(R.id.textView_sex);
        TextView ageText = (TextView) findViewById(R.id.textView_age);
        TextView chartText = (TextView) findViewById(R.id.textView_chart);
        TextView handText = (TextView) findViewById(R.id.textView_hand);
        TextView stateText = (TextView) findViewById(R.id.textView_state);
        TextView etcText = (TextView) findViewById(R.id.textView_etc);
        Gallery gallery = (Gallery) findViewById(R.id.gallery);

        ImageAdapter adapter = new ImageAdapter();
        gallery.setAdapter(adapter);

        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String sex = intent.getStringExtra("sex");
        String age = intent.getStringExtra("age");
        String handling = intent.getStringExtra("handling");
        String chart = intent.getStringExtra("chart");
        String desexualize = intent.getStringExtra("desexualize");
        String state = intent.getStringExtra("state");
        String etc = intent.getStringExtra("etc");
        // byte로 받은 파일 bitmap으로 변환하기
//        byte[] arr = intent.getByteArrayExtra("image");
//        Bitmap bitmap = BitmapFactory.decodeByteArray(arr,0,arr.length);



        nameText.setText(name);
        sexText.setText(sex + ", " + desexualize);
        ageText.setText(age);
        chartText.setText(chart);
        handText.setText(handling);
        stateText.setText(state);
        etcText.setText(etc);

    }

    class ImageAdapter extends BaseAdapter {
        int[] items = {R.drawable.homubird, R.drawable.homuarmy, R.drawable.sickhomu};

        @Override
        public int getCount() {
            return items.length;
        }

        @Override
        public Object getItem(int position) {
            return items[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ImageView view = new ImageView(getApplicationContext());
            view.setImageResource(items[position]);

            BitmapDrawable drawable = (BitmapDrawable) view.getDrawable();

            return view;
        }
    }

}
