package org.techtown.work1;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class Input_Write extends AppCompatActivity {
    EditText editText1,editText2,editText3;
    Button button1;
    String[] items = {"남성","여성"};
    Spinner spinner;
    ImageView imageView;
    String text2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_write);
        imageView=(ImageView)findViewById(R.id.photo);
        ;

        editText1 = (EditText)findViewById(R.id.editText);
        editText2 = (EditText)findViewById(R.id.editText2);
        editText3 = (EditText)findViewById(R.id.editText3);
        button1=(Button)findViewById(R.id.button1);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMessage();
            }
        });


        /*스피너 설정*/
        spinner = (Spinner)findViewById(R.id.spinner);
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,items);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                text2=items[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text1 = editText1.getText().toString();
                String text3 = editText2.getText().toString();
                String text4 = editText3.getText().toString();
                Bitmap bitmap = ((BitmapDrawable)imageView.getDrawable()).getBitmap();

                //비트맵 크기 줄이기
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG,100,stream);
                byte[] byteArray = stream.toByteArray();

                Intent intent = getIntent();
                intent.putExtra("name",text1);
                intent.putExtra("sex",text2);
                intent.putExtra("age",text3);
                intent.putExtra("properties",text4);
                intent.putExtra("image",byteArray);
                setResult(RESULT_OK,intent);

                finish();

            }
        });

    }
    public void showMessage(){


        AlertDialog.Builder builder = new AlertDialog.Builder (this);
        builder.setTitle("사진 추가");


        builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType(MediaStore.Images.Media.CONTENT_TYPE);
                //  intent.setType("image/*");  //이미지 파일 가져오기
                //   intent.setAction(Intent.ACTION_GET_CONTENT); //CONTENT 가져오기
                startActivityForResult(intent,1);
            }
        });
        builder.setPositiveButton("아니오", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });


        AlertDialog dialog = builder.create();
        dialog.show();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode==1){
            if(resultCode==RESULT_OK){
                try{
                    InputStream in = null; //데이터 가져오기
                    in = getContentResolver().openInputStream(data.getData());  //데이터 공유 방식으로 resolver는 데이터를 받는 객체
                    //따라서 위 코드는 데이터로부터 정보를 받아 in에 저장하는 것이다.
                    Bitmap img = BitmapFactory.decodeStream(in);   //in으로 들어 온 데이터 해석
                    in.close();
                    imageView.setImageBitmap(img);   //이미지 표시

                }
                catch (FileNotFoundException e) {
                    Toast.makeText(getApplicationContext(),"파일을 찾을 수 없습니다. ",Toast.LENGTH_LONG).show();
                } catch (IOException e) {
                    Toast.makeText(getApplicationContext(),"파일을 닫을 수 없습니다. ",Toast.LENGTH_LONG).show();
                }


            }
        }
    }
}