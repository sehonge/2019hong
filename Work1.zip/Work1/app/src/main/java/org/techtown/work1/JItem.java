package org.techtown.work1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class JItem extends AppCompatActivity {
    ListAdapter adapter;

    ArrayList<ListItem> finalJlist = new ArrayList<ListItem>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_j_item);

        ListView listView = (ListView) findViewById(R.id.listView);
        adapter = new ListAdapter();
        listView.setAdapter(adapter);

        Intent intent = getIntent();
        finalJlist = (ArrayList<ListItem>) intent.getSerializableExtra("jlist");
        for (int i = 0; i < finalJlist.size(); i++) {
            adapter.addItem(finalJlist.get(i));
            adapter.notifyDataSetChanged();
        }
    }
}
