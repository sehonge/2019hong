package org.techtown.work1;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.LinearLayout;

import java.util.ArrayList;

public class KFrag extends Fragment {
    Documentation activity;
    ViewGroup rootView;
    public static CatAdapter adapter;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        activity = (Documentation)getActivity();
    }


    @Override
    public void onDetach() {
        super.onDetach();

        activity = null;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        rootView = (ViewGroup)inflater.inflate(R.layout.fragment_k, container, false);
        GridView gridView = (GridView)rootView.findViewById(R.id.gridView);

        adapter= new CatAdapter();
//        adapter.addItem(new CatItem(R.drawable.homuhomu, "호무호무"));
//        adapter.addItem(new CatItem(R.drawable.homubird, "호무새"));
//        adapter.addItem(new CatItem(R.drawable.starfish, "뚱이"));
//        adapter.addItem(new CatItem(R.drawable.teemo, "귀여운 티모"));
        gridView.setAdapter(adapter);

        Button button_input = (Button) rootView.findViewById(R.id.button_input);
        Button button_back = (Button) rootView.findViewById(R.id.button_backK);

        button_input.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.onFragmentChange(10);
            }
        });
        button_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.ChangeFragment(3);
            }
        });

        return rootView;
    }


}