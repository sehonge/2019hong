package org.techtown.work1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import org.techtown.work1.R;

import java.util.ArrayList;

public class KItem extends AppCompatActivity {

    ListAdapter adapter;

    ArrayList<ListItem> Klist = new ArrayList<ListItem>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_k_item);

        ListView listView = (ListView) findViewById(R.id.listView);
        adapter = new ListAdapter();

        Intent intent = getIntent();
        Klist = (ArrayList<ListItem>) intent.getSerializableExtra("list2");
        for (int i = 0; i < Klist.size(); i++) {
            adapter.addItem(Klist.get(i));
        }
        listView.setAdapter(adapter);


    }
}
