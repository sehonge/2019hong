package org.techtown.work1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class List extends AppCompatActivity {

    ArrayList<ListItem> Klist = new ArrayList<ListItem>();
    ArrayList<ListItem> Jlist = new ArrayList<ListItem>();
    ArrayList<ListItem> Dlist = new ArrayList<ListItem>();
    ArrayList<ListItem> Xlist = new ArrayList<ListItem>();
    ArrayList<ListItem> Tomolist = new ArrayList<ListItem>();
    ArrayList<ListItem> GAlist = new ArrayList<ListItem>();
    ArrayList<ListItem> Gonlist = new ArrayList<ListItem>();
    ArrayList<ListItem> Allist = new ArrayList<ListItem>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        DiaryConnector url = new DiaryConnector();
        url.start();

        try {
            url.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        String result = url.getTemp();
        ParseJSON(result);

        Button k = (Button) findViewById(R.id.Kim);
        k.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Diary_K.class);
                intent.putExtra("klist", Klist);
                startActivity(intent);
            }
        });
        Button j = (Button) findViewById(R.id.Jung);
        j.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Diary_J.class);
                intent.putExtra("jlist", Jlist);
                startActivity(intent);
            }
        });

        Button d = (Button) findViewById(R.id.Dasan);
        d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Diary_D.class);
                intent.putExtra("dlist", Dlist);
                startActivity(intent);
            }
        });
        Button x = (Button) findViewById(R.id.Xavi);
        x.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Diary_X.class);
                intent.putExtra("xlist", Xlist);
                startActivity(intent);

            }
        });
        Button t = (Button) findViewById(R.id.Tomo);
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Diary_T.class);
                intent.putExtra("tlist", Tomolist);
                startActivity(intent);
            }
        });
        Button ga = (Button) findViewById(R.id.GA);
        ga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Diary_Ga.class);
                intent.putExtra("galist", GAlist);
                startActivity(intent);
            }
        });
        Button gon = (Button) findViewById(R.id.Gon);
        gon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Diary_Gon.class);
                intent.putExtra("gonlist", Gonlist);
                startActivity(intent);
            }
        });
        Button al = (Button) findViewById(R.id.Alba);
        al.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Diary_Al.class);
                intent.putExtra("allist", Allist);
                startActivity(intent);
            }
        });


    }

    public void ParseJSON(String target) {
        String food = null;
        String water = null;
        String weather = null;
        String note = null;
        String manager = null;
        String day = null;
        String time = null;
        String fc = null;

        try {
            JSONObject json = new JSONObject(target);

            JSONArray arr = json.getJSONArray("result");

            for (int i = 0; i < arr.length(); i++) {
                JSONObject json2 = arr.getJSONObject(i);

                food = json2.getString("food");
                water = json2.getString("water");
                weather = json2.getString("weather");
                note = json2.getString("note");
                manager = json2.getString("manager");
                day = json2.getString("day");
                time = json2.getString("time");
                fc = json2.getString("fc");

                if (fc.equals("1")) {
                    Jlist.add(new ListItem(food, water, weather, note, manager, day, time));
                } else if (fc.equals("2")) {
                    Klist.add(new ListItem(food, water, weather, note, manager, day, time));
                } else if (fc.equals("3")) {
                    Dlist.add(new ListItem(food, water, weather, note, manager, day, time));
                } else if (fc.equals("4")) {
                    Xlist.add(new ListItem(food, water, weather, note, manager, day, time));
                } else if (fc.equals("5")) {
                    Tomolist.add(new ListItem(food, water, weather, note, manager, day, time));
                } else if (fc.equals("6")) {
                    GAlist.add(new ListItem(food, water, weather, note, manager, day, time));
                } else if (fc.equals("7")) {
                    Gonlist.add(new ListItem(food, water, weather, note, manager, day, time));
                } else if (fc.equals("8")) {
                    Allist.add(new ListItem(food, water, weather, note, manager, day, time));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
