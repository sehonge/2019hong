package org.techtown.work1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class List extends AppCompatActivity {

    Button kim;
    ArrayList<ListItem> tokitemklist=new ArrayList<ListItem>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        Intent intent = getIntent();
        tokitemklist=(ArrayList<ListItem>)intent.getSerializableExtra("list");



        kim = (Button) findViewById(R.id.Kim);
        kim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), KItem.class);
                intent.putExtra("list2",tokitemklist);
                startActivity(intent);
            }
        });

    }
}
