package org.techtown.work1;

import android.content.Intent;
import android.os.Parcelable;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class List extends AppCompatActivity {


    ListFrag list;
    Diary_k diary_k;
    Diary_j diary_j;
    Diary_d diary_d;
    Diary_x diary_x;
    Diary_tomo diary_t;
    Diary_ga diary_ga;
    Diary_gon diary_gon;
    Diary_al diary_al;

    ArrayList<ListItem> Klist=new ArrayList<ListItem>();
    ArrayList<ListItem> Jlist=new ArrayList<ListItem>();
    ArrayList<ListItem> Dlist=new ArrayList<ListItem>();
    ArrayList<ListItem> Xlist=new ArrayList<ListItem>();
    ArrayList<ListItem> Tomolist=new ArrayList<ListItem>();
    ArrayList<ListItem> GAlist=new ArrayList<ListItem>();
    ArrayList<ListItem> Gonlist=new ArrayList<ListItem>();
    ArrayList<ListItem> Allist=new ArrayList<ListItem>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        DiaryConnector url = new DiaryConnector();
        url.start();

        try{
            url.join();
        }catch(InterruptedException e){
            e.printStackTrace();;
        }
        String result = url.getTemp();
        ParseJSON(result);



        Intent intent = getIntent();
        String locate=intent.getStringExtra("locate");

        try {
            if (locate.equals("J관")) {
                FragmentChange(2);
            } else if (locate.equals("K관")) {
                FragmentChange(1);
            } else if (locate.equals("D관")) {
                FragmentChange(3);
            } else if (locate.equals("X관")) {
                FragmentChange(4);
            } else if (locate.equals("Tomo관")) {
                FragmentChange(5);
            } else if (locate.equals("GA관")) {
                FragmentChange(6);
            } else if (locate.equals("곤쓰")) {
                FragmentChange(7);
            } else if (locate.equals("알탑")) {
                FragmentChange(8);
            }
        }
        catch(NullPointerException e){
            list = new ListFrag();
            getSupportFragmentManager().beginTransaction().add(R.id.container,list).commit();
        }



    }
    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }

    public void FragmentChange(int index){
        diary_k = new Diary_k();
        diary_j = new Diary_j();
        diary_d = new Diary_d();
        diary_x = new Diary_x();
        diary_t = new Diary_tomo();
        diary_ga = new Diary_ga();
        diary_gon = new Diary_gon();
        diary_al = new Diary_al();
        if(index==0){
            getSupportFragmentManager().beginTransaction().replace(R.id.container,list).commit();
        }
        else if (index==1){
            Bundle bundle = new Bundle();
            bundle.putSerializable("klist",Klist);
            diary_k.setArguments(bundle);
            getSupportFragmentManager().beginTransaction().replace(R.id.container,diary_k).commit();
        }
        else if (index==2){
            Bundle bundle = new Bundle();
            bundle.putSerializable("jlist",Jlist);
            diary_j.setArguments(bundle);
            getSupportFragmentManager().beginTransaction().replace(R.id.container,diary_j).commit();
        }
        else if (index==3){
            Bundle bundle = new Bundle();
            bundle.putSerializable("dlist",Dlist);
            diary_d.setArguments(bundle);
            getSupportFragmentManager().beginTransaction().replace(R.id.container,diary_d).commit();
        }
        else if (index==4){
            Bundle bundle = new Bundle();
            bundle.putSerializable("xlist",Xlist);
            diary_x.setArguments(bundle);
            getSupportFragmentManager().beginTransaction().replace(R.id.container,diary_x).commit();
        }
        else if (index==5){Bundle bundle = new Bundle();
            bundle.putSerializable("tlist",Tomolist);
            diary_t.setArguments(bundle);
            getSupportFragmentManager().beginTransaction().replace(R.id.container,diary_t).commit();
        }
        else if (index==6){
            Bundle bundle = new Bundle();
            bundle.putSerializable("galist",GAlist);
            diary_ga.setArguments(bundle);
            getSupportFragmentManager().beginTransaction().replace(R.id.container,diary_ga).commit();
        }
        else if (index==7){
            Bundle bundle = new Bundle();
            bundle.putSerializable("gonlist",Gonlist);
            diary_gon.setArguments(bundle);
            getSupportFragmentManager().beginTransaction().replace(R.id.container,diary_gon).commit();
        }
        else if (index==8){
            Bundle bundle = new Bundle();
            bundle.putSerializable("allist",Allist);
            diary_al.setArguments(bundle);
            getSupportFragmentManager().beginTransaction().replace(R.id.container,diary_al).commit();
        }

    }
    public void ParseJSON(String target){
        String food=null;
        String water=null;
        String weather=null;
        String note=null;
        String manager=null;
        String day=null;
        String time=null;
        String fc=null;
        String id = null;

        try{
            JSONObject json = new JSONObject(target);

            JSONArray arr= json.getJSONArray("result");

            for(int i=0;i<arr.length();i++){
                JSONObject json2 = arr.getJSONObject(i);

                food=json2.getString("food");
                water=json2.getString("water");
                weather=json2.getString("weather");
                note=json2.getString("note");
                manager=json2.getString("manager");
                day=json2.getString("day");
                time=json2.getString("time");
                fc=json2.getString("fc");
                id=json2.getString("id");

                if(fc.equals("1")){
                    Jlist.add(new ListItem(food,water,weather,note,manager,day,time,id,fc));
                }
                else if(fc.equals("2")){
                    Klist.add(new ListItem(food,water,weather,note,manager,day,time,id,fc));
                }
                else if(fc.equals("3")){
                    Dlist.add(new ListItem(food,water,weather,note,manager,day,time,id,fc));
                }
                else if(fc.equals("4")){
                    Xlist.add(new ListItem(food,water,weather,note,manager,day,time,id,fc));
                }
                else if(fc.equals("5")){
                    Tomolist.add(new ListItem(food,water,weather,note,manager,day,time,id,fc));
                }
                else if(fc.equals("6")){
                    GAlist.add(new ListItem(food,water,weather,note,manager,day,time,id,fc));
                }
                else if(fc.equals("7")){
                    Gonlist.add(new ListItem(food,water,weather,note,manager,day,time,id,fc));
                }
                else if(fc.equals("8")){
                    Allist.add(new ListItem(food,water,weather,note,manager,day,time,id,fc));
                }
            }

        }
        catch(Exception e){
            e.printStackTrace();
        }

    }


}