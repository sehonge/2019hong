package org.techtown.work1;

import android.content.Context;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


public class ListFrag extends Fragment {
    List activity;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        activity=(List)getActivity();

    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup)inflater.inflate(R.layout.fragment_list,container,false);


        Button k = (Button)rootView.findViewById(R.id.Kim);
        k.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.FragmentChange(1);
            }
        });
        Button j = (Button)rootView.findViewById(R.id.Jung);
        j.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.FragmentChange(2);
            }
        });

        Button d = (Button)rootView.findViewById(R.id.Dasan);
        d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.FragmentChange(3);
            }
        });
        Button x = (Button)rootView.findViewById(R.id.Xavi);
        x.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.FragmentChange(4);
            }
        });
        Button t = (Button)rootView.findViewById(R.id.Tomo);
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.FragmentChange(5);
            }
        });
        Button ga = (Button)rootView.findViewById(R.id.GA);
        ga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.FragmentChange(6);
            }
        });
        Button gon = (Button)rootView.findViewById(R.id.Gon);
        gon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.FragmentChange(7);
            }
        });
        Button al = (Button)rootView.findViewById(R.id.Alba);
        al.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.FragmentChange(8);
            }
        });

        return rootView;

    }

}