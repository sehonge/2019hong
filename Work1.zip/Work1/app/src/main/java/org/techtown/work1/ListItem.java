package org.techtown.work1;

import android.os.Parcel;
import android.os.Parcelable;

public class ListItem implements Parcelable {
    String food;
    String water;
    String weather;
    String note;
    String manager;
    String day;
    String time;
    String idnum;
    String fc;

    public ListItem(String food, String water, String weather, String note, String manager, String day, String time, String idnum,String fc) {
        this.food = food;
        this.water = water;
        this.weather = weather;
        this.note = note;
        this.manager = manager;
        this.day = day;
        this.time = time;
        this.idnum = idnum;
        this.fc = fc;
    }

    protected ListItem(Parcel in) {
        food = in.readString();
        water = in.readString();
        weather = in.readString();
        note = in.readString();
        manager = in.readString();
        day = in.readString();
        time = in.readString();
        idnum = in.readString();
        fc = in.readString();
    }

    public static final Creator<ListItem> CREATOR = new Creator<ListItem>() {
        @Override
        public ListItem createFromParcel(Parcel in) {
            return new ListItem(in);
        }

        @Override
        public ListItem[] newArray(int size) {
            return new ListItem[size];
        }
    };

    public String getFood() {
        return food;
    }

    public void setFood(String food) {
        this.food = food;
    }

    public String getWater() {
        return water;
    }

    public void setWater(String water) {
        this.water = water;
    }

    public String getWeather() {
        return weather;
    }

    public void setWeather(String weather) {
        this.weather = weather;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getManager() {
        return manager;
    }

    public void setManager(String manager) {
        this.manager = manager;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getIdnum() {
        return idnum;
    }

    public void setIdnum(String idnum) {
        this.idnum = idnum;
    }

    public String getFc() {
        return fc;
    }

    public void setFc(String fc) {
        this.fc = fc;
    }

    public static Creator<ListItem> getCREATOR() {
        return CREATOR;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(food);
        dest.writeString(water);
        dest.writeString(weather);
        dest.writeString(note);
        dest.writeString(manager);
        dest.writeString(day);
        dest.writeString(time);
        dest.writeString(idnum);
        dest.writeString(fc);

    }
}