package org.techtown.work1;

import android.os.Parcel;
import android.os.Parcelable;

public class ListItem implements Parcelable {
    String writer;
    String food;
    String water;
    String time;
    int resId;
    String extrainformation;

    public ListItem(String writer, String food, String water, String time, int resId, String extrainformation) {
        this.writer = writer;
        this.food = food;
        this.water = water;
        this.time = time;
        this.resId = resId;
        this.extrainformation = extrainformation;
    }

    protected ListItem(Parcel in) {
        writer = in.readString();
        food = in.readString();
        water = in.readString();
        time = in.readString();
        resId = in.readInt();
        extrainformation = in.readString();
    }

    public static final Creator<ListItem> CREATOR = new Creator<ListItem>() {
        @Override
        public ListItem createFromParcel(Parcel in) {
            return new ListItem(in);
        }

        @Override
        public ListItem[] newArray(int size) {
            return new ListItem[size];
        }
    };

    public String getWriter() {
        return writer;
    }

    public void setWriter(String writer) {
        this.writer = writer;
    }

    public String getFood() {
        return food;
    }

    public void setFood(String food) {
        this.food = food;
    }

    public String getWater() {
        return water;
    }

    public void setWater(String water) {
        this.water = water;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getResId() {
        return resId;
    }

    public void setResId(int resId) {
        this.resId = resId;
    }

    public String getExtrainformation() {
        return extrainformation;
    }

    public void setExtrainformation(String extrainformation) {
        this.extrainformation = extrainformation;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(writer);
        dest.writeString(food);
        dest.writeString(water);
        dest.writeString(time);
        dest.writeInt(resId);
        dest.writeString(extrainformation);
    }
}