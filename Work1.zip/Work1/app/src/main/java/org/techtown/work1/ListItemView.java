package org.techtown.work1;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class ListItemView extends LinearLayout {

    TextView writertext;
    TextView foodtext;
    TextView watertext;
    TextView timetext;
    ImageView weatherimage;
    TextView extratext;
    RelativeLayout container;
    ImageButton exit;
    Button morebutton;

    public ListItemView(Context context) {
        super(context);

        init(context);
    }

    public ListItemView(Context context, AttributeSet attrs) {
        super(context, attrs);

        init(context);
    }

    public void init(Context context){
        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.list_item,this,true);
        writertext=(TextView)findViewById(R.id.writertext);
        foodtext=(TextView)findViewById(R.id.foodtext);
        watertext=(TextView)findViewById(R.id.watertext);
        timetext=(TextView)findViewById(R.id.timetext);
        weatherimage=(ImageView)findViewById(R.id.weatherimage);
        extratext=(TextView)findViewById(R.id.moretext);
        container=(RelativeLayout)findViewById(R.id.morebox);
        exit=(ImageButton)findViewById(R.id.imageButton);
        morebutton=(Button)findViewById(R.id.more);
        morebutton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                container.setVisibility(View.VISIBLE);
            }
        });
        exit.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                container.setVisibility(View.INVISIBLE);
            }
        });
    }
    public void setWriter(String writer){
        writertext.setText(writer);
    }
    public void setFood(String food){
        foodtext.setText(food);
    }
    public void setWater(String water){
        watertext.setText(water);
    }
    public void setTime(String time){
        timetext.setText(time);
    }
    public void setWeather(int resId){
        weatherimage.setImageResource(resId);
    }
    public void settext(String extrainformation){extratext.setText(extrainformation);}

}