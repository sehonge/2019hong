package org.techtown.work1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity {

    String idstr;
    String passwordstr;
    String id;
    String password;
    EditText idtext;
    EditText passwordtext;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        idtext = (EditText) findViewById(R.id.idText);
        passwordtext = (EditText) findViewById(R.id.passwordText);

        LoginConnector url = new LoginConnector();
        url.start();

        try {
            url.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        String result = url.getTemp();

        ParseJSON(result);

        Button login = (Button) findViewById(R.id.loginactivity);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                idstr = idtext.getText().toString();
                passwordstr = passwordtext.getText().toString();
                if (!idstr.equals(id)) {
                    Toast.makeText(getApplicationContext(), "아이디를 확인하세요", Toast.LENGTH_LONG).show();
                } else if (!passwordstr.equals(password)) {
                    Toast.makeText(getApplicationContext(), "비밀번호를 확인하세요", Toast.LENGTH_LONG).show();
                } else {
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                }
            }
        });
    }

    public void ParseJSON(String target) {

        try {
            JSONObject json = new JSONObject(target);

            JSONArray arr = json.getJSONArray("result");

            JSONObject json2 = arr.getJSONObject(1);
            id = json2.getString("id");
            password = json2.getString("password");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}