package org.techtown.work1;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;

import java.util.ArrayList;

public class MainGateFrag extends Fragment {
    Documentation activity;
    public static CatAdapter adapter;
    ViewGroup rootView;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        activity = (Documentation)getActivity();
    }

    @Override
    public void onDetach() {
        super.onDetach();

        activity = null;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        adapter=new CatAdapter();
        rootView = (ViewGroup)inflater.inflate(R.layout.fragment_maingate, container, false);
        GridView gridView2 = (GridView)rootView.findViewById(R.id.gridView2);
        adapter.addItem(new CatItem(R.drawable.homubird, "호무새"));
        adapter.addItem(new CatItem(R.drawable.teemo, "귀여운 티모"));
        adapter.addItem(new CatItem(R.drawable.starfish, "뚱이"));
        adapter.addItem(new CatItem(R.drawable.catimo, "고양이"));
        adapter.addItem(new CatItem(R.drawable.fivefive, "오오도발"));
        gridView2.setAdapter(adapter);

        gridView2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                long index=adapter.getItemId(position);
                activity.onFragmentChange((int)index);
            }
        });




        Button button_input = (Button) rootView.findViewById(R.id.button_input);
        Button button_back = (Button) rootView.findViewById(R.id.button_backM);

        button_input.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.onFragmentChange(10);
            }
        });

        button_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.ChangeFragment(3);
            }
        });

        return rootView;
    }
   /* private class CatAdapter2 extends BaseAdapter {
        ArrayList<CatItem> items = new ArrayList<CatItem>();

        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public Object getItem(int position) {
            return items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        public void addItem(CatItem item){
            items.add(item);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            CatItemView view = new CatItemView(rootView.getContext());
            CatItem item = items.get(position);
            view.setImageView(item.getResId());

            return view;
        }
    }*/




}
