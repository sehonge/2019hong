package org.techtown.work1;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import static android.app.Activity.RESULT_OK;

public class MainGateFrag extends Fragment {
    Documentation activity;
    public static CatAdapter adapter;
    ViewGroup rootView;
    ArrayList<CatInformation> catinform = new ArrayList<CatInformation>();
    phpDown task;
    GridView gridView2;
    TextView textView;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        activity = (Documentation) getActivity();
    }

    @Override
    public void onDetach() {
        super.onDetach();

        activity = null;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        adapter = new CatAdapter();
        rootView = (ViewGroup) inflater.inflate(R.layout.fragment_maingate, container, false);
        gridView2 = (GridView) rootView.findViewById(R.id.gridView2);
        textView = (TextView) rootView.findViewById(R.id.textView_ex);

        String ipAddress = "10.1.171.140";

        task = new phpDown();
        task.execute("http://10.1.145.174/data.php");

//        gridView2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                CatItem item = (CatItem) adapter.getItem(position);
//                for (int i = 0; i < catinform.size(); i++) {
//                    CatInformation candidate = catinform.get(i);
//                    if (candidate.getData(0) == item.name) {
//                        Intent intent = new Intent(getContext(), InputAct.class);
//
//                        intent.putExtra("name", candidate.getData(0));
//                        intent.putExtra("sex", candidate.getData(1));
//                        intent.putExtra("age", candidate.getData(2));
//                        intent.putExtra("handling", candidate.getData(3));
//                        intent.putExtra("desexualize", candidate.getData(4));
//                        intent.putExtra("state", candidate.getData(5));
//                        intent.putExtra("chart", candidate.getData(6));
//                        intent.putExtra("etc", candidate.getData(7));
//                        //intent.putExtra("image", byteArray);
//                        startActivity(intent);
//                        activity.onFragmentChange(0);
//
//                    }
//                }
//            }
//        });


        Button button_back = (Button) rootView.findViewById(R.id.button_backM);

        button_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.ChangeFragment(3);
            }
        });

        return rootView;
    }

    private class phpDown extends AsyncTask<String, Integer, String> {

        @Override
        protected String doInBackground(String... urls) {
            StringBuilder jsonHtml = new StringBuilder();
            try {
                URL url = new URL(urls[0]);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                if(conn != null) {
                    conn.setConnectTimeout(10000);
                    conn.setUseCaches(false);

                    if(conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));

                        for(;;) {
                            String line = br.readLine();
                            if(line == null)
                                break;
                            jsonHtml.append(line + "\n");
                        }
                        br.close();
                    }
                    conn.disconnect();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return jsonHtml.toString();
        }

        protected void onPostExecute(String str) {
            String name;
            String sex;
            String age;
            String handling;
            String desexualize;
            String state;
            String chart;
            String etc;

            try {
                JSONObject root = new JSONObject(str);
                JSONArray ja = root.getJSONArray("results");

                for(int i = 0; i < ja.length(); i ++) {
                    JSONObject jo = ja.getJSONObject(i);
                    name = jo.getString("name");
                    sex = jo.getString("sex");
                    age = jo.getString("age");
                    handling = jo.getString("handling");
                    desexualize = jo.getString("desexualize");
                    state = jo.getString("state");
                    chart = jo.getString("chart");
                    etc = jo.getString("etc");

                    catinform.add(new CatInformation(name, sex, age, handling, desexualize, state, chart, etc));

                    Bitmap file1 = BitmapFactory.decodeResource(getResources(), R.drawable.homubird);
                    adapter.addItem(new CatItem(file1, name));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

            gridView2.setAdapter(adapter);
            textView.setText(catinform.get(0).getData(0));

            gridView2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    CatItem item = (CatItem) adapter.getItem(position);
                    for (int i = 0; i < catinform.size(); i++) {
                        CatInformation candidate = catinform.get(i);

                        if (candidate.getData(0) == item.name) {
                            Intent intent = new Intent(getContext(), InputAct.class);

                            intent.putExtra("name", candidate.getData(0));
                            intent.putExtra("sex", candidate.getData(1));
                            intent.putExtra("age", candidate.getData(2));
                            intent.putExtra("handling", candidate.getData(3));
                            intent.putExtra("desexualize", candidate.getData(4));
                            intent.putExtra("state", candidate.getData(5));
                            intent.putExtra("chart", candidate.getData(6));
                            intent.putExtra("etc", candidate.getData(7));
                            //intent.putExtra("image", byteArray);
                            startActivity(intent);

                        }
                    }
                }
            });


        }

    }



}