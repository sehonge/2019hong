package org.techtown.work1;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

import static android.app.Activity.RESULT_OK;

public class MainGateFrag extends Fragment {
    Documentation activity;
    public static CatAdapter adapter;
    ViewGroup rootView;
    ArrayList<CatInformation> catinform = new ArrayList<CatInformation>();


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        activity = (Documentation) getActivity();
    }

    @Override
    public void onDetach() {
        super.onDetach();

        activity = null;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        adapter = new CatAdapter();
        rootView = (ViewGroup) inflater.inflate(R.layout.fragment_maingate, container, false);
        GridView gridView2 = (GridView) rootView.findViewById(R.id.gridView2);

        Bitmap file1 = BitmapFactory.decodeResource(getResources(), R.drawable.homubird);
        Bitmap file2 = BitmapFactory.decodeResource(getResources(), R.drawable.teemo);
        Bitmap file3 = BitmapFactory.decodeResource(getResources(), R.drawable.starfish);
        Bitmap file4 = BitmapFactory.decodeResource(getResources(), R.drawable.catimo);
        Bitmap file5 = BitmapFactory.decodeResource(getResources(), R.drawable.fivefive);
        adapter.addItem(new CatItem(file1, "호무새"));
        adapter.addItem(new CatItem(file2, "귀여운 티모"));
        adapter.addItem(new CatItem(file3, "뚱이"));
        adapter.addItem(new CatItem(file4, "고양이"));
        adapter.addItem(new CatItem(file5, "오오도발"));
        gridView2.setAdapter(adapter);

        catinform.add(new CatInformation("호무새", "남성", 2, "모름", file1));
        catinform.add(new CatInformation("귀여운 티모", "여성", 1, "모름", file2));
        catinform.add(new CatInformation("뚱이", "남성", 3, "모름", file3));
        catinform.add(new CatInformation("고양이", "여성", 4, "모름", file4));
        catinform.add(new CatInformation("오오도발", "남성", 5, "모름", file5));

        gridView2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                CatItem item = (CatItem) adapter.getItem(position);
                for (int i = 0; i < catinform.size(); i++) {
                    CatInformation candidate = catinform.get(i);
                    if (candidate.name == item.name) {
                        Intent intent = new Intent(getContext(), InputAct.class);
                        //비트맵 용량 줄이기
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        candidate.bitmapfile.compress(Bitmap.CompressFormat.JPEG, 100, stream);
                        byte[] byteArray = stream.toByteArray();

                        intent.putExtra("name", candidate.name);
                        intent.putExtra("sex", candidate.sex);
                        intent.putExtra("age", candidate.age);
                        intent.putExtra("properties", candidate.properties);
                        intent.putExtra("image", byteArray);
                        startActivity(intent);
                    }
                }
            }
        });


        Button button_input = (Button) rootView.findViewById(R.id.button_input);
        Button button_back = (Button) rootView.findViewById(R.id.button_backM);

        button_input.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent callIntent = new Intent(getContext(), Input_Write.class);
                startActivityForResult(callIntent, 3000);
            }
        });

        button_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.ChangeFragment(3);
            }
        });

        return rootView;
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case 3000:
                    int age = 0;
                    String name = data.getStringExtra("name");
                    String sex = data.getStringExtra("sex");
                    String properties = data.getStringExtra("properties");
                    String agee = data.getStringExtra("age");
                    age = Integer.parseInt(agee);
                    byte[] arr = data.getByteArrayExtra("image");
                    Bitmap bitmapfile = BitmapFactory.decodeByteArray(arr, 0, arr.length);

                    catinform.add(new CatInformation(name, sex, age, properties, bitmapfile));

                    adapter.addItem(new CatItem(bitmapfile, name));
                    adapter.notifyDataSetChanged();

            }
        }
    }


}