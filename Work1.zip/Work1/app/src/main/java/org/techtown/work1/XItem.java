package org.techtown.work1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class XItem extends AppCompatActivity {

    ListAdapter adapter;

    ArrayList<ListItem> finalXlist = new ArrayList<ListItem>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_x_item);

        ListView listView = (ListView) findViewById(R.id.listView);
        adapter = new ListAdapter();
        listView.setAdapter(adapter);

        Intent intent = getIntent();
        finalXlist = (ArrayList<ListItem>) intent.getSerializableExtra("xlist");
        for (int i = 0; i < finalXlist.size(); i++) {
            adapter.addItem(finalXlist.get(i));
            adapter.notifyDataSetChanged();
        }
    }
}
